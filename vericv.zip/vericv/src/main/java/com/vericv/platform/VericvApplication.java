package com.vericv.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VericvApplication {

	public static void main(String[] args) {
		SpringApplication.run(VericvApplication.class, args);
	}

}
