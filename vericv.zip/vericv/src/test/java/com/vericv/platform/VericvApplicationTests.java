package com.vericv.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VericvApplicationTests {

	@Test
	void contextLoads() {
	}

}
